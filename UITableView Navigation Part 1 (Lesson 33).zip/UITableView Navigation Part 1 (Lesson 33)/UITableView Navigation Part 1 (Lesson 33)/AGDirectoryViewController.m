//
//  AGDirectoryViewController.m
//  UITableView Navigation Part 1 (Lesson 33)
//
//  Created by Anton Gorlov on 05.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGDirectoryViewController.h"

@interface AGDirectoryViewController ()

@property (strong, nonatomic) NSString* path; // соз путь,чтобы его хранить
@property (strong, nonatomic) NSArray* contents; //соз массив,чтобы мы могли не переживать,что содержимое папки измениться и таблица перестанет работать (contents - имена файлов и директорий)
@end

@implementation AGDirectoryViewController


- (id) initWithFolderPath:(NSString *) path {

    self = [super initWithStyle:UITableViewStylePlain];
    
    if (self) {
        self.path = path;
        
        NSError* error = nil; //соз error (ошибки нет)если будет,то появиться
        
        self.contents = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:self.path //передаем путь
                                                                            error:&error]; //заполняем массив (contents) строками это названи файлов или директорий кот у нас лежат.
        
        
        if (error) { //если ошибка,то
            
            NSLog(@"%@",[error localizedDescription]); //он обвернет ее так как передаем указатель,он заполнит своей ошибкой
        
        }//localizedDescription - вывидет какое-то локализированное сообщение
    }
    
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //покажем последний компонент в шапке (где находимся) бла/блабла/бла2, бла2-последний компонент,где находимся

    self.navigationItem.title = [self.path lastPathComponent];
    
    
    //при нажатии на кнопку переходит на главный ViewController
    
    if ([self.navigationController.viewControllers count] > 1) { //если Controller не находится на 1-м стеке ,то ...
        UIBarButtonItem* item = [[UIBarButtonItem alloc] initWithTitle:@"Back to Root" style:UIBarButtonItemStylePlain
                                                                target:self
                                                                action:@selector(actionBackToRoot:)]; //уничтожает все viewControllers и возвращается на главный viewController
        
        self.navigationItem.rightBarButtonItem = item;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return [self.contents count]; //выводим массив наших contents (кол-во содерж файлов и папок)

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    static NSString* identifier = @"cell";
    
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:identifier]; // метод пытаеться взять ячейку с identifier (ее там нет,нужно создать)
    
    if (!cell) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier]; // соз ячейку
        
    }
    //кол-во рядов,это кол-во элементов в массиве
    
    NSString* fileName = [self.contents objectAtIndex:indexPath.row]; //соз строки на основе массива обьктов по индексу
    
    cell.textLabel.text = fileName; //ставим в textLabel
    
    if ([self isDirectoryAtIndexPath:indexPath]) {
        
        cell.imageView.image = [UIImage imageNamed:@"folder.png"];
        
    }else {
    
        cell.imageView.image = [UIImage imageNamed:@"file.png"];
    }
    
    
    return cell;

}

#pragma mark - UITableViewDelegate

// При нажатии на папку идем дальше (на файл - ничего)

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath { //когда нажали
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES]; //чтобы не был выбранным
    
    if ([self isDirectoryAtIndexPath:indexPath]) { //проверяем директория это или нет
        
        NSString* fileName = [self.contents objectAtIndex:indexPath.row];
        
        NSString* path = [self.path stringByAppendingPathComponent:fileName]; // инициализируем path
        
        AGDirectoryViewController* vc = [[AGDirectoryViewController alloc] initWithFolderPath:path]; //соз в нашем  Controller обьекта класса AGDirVC точно такой же обьяект такого класса (но он не заработает ,пока не поставим в стек)
        
        [self.navigationController pushViewController:vc animated:YES]; // добавляем на стек наших контроллеры на navigationController
    }

}

#pragma mark - Methods

//определим папка это или файл
- (BOOL) isDirectoryAtIndexPath:(NSIndexPath*) indexPath {

    NSString* fileName = [self.contents objectAtIndex:indexPath.row]; //берем fileName из contents по indexPath (это последний contents,он не вкл весь path)
    
    NSString* filePath = [self.path stringByAppendingPathComponent:fileName]; //добавляем строку в путь компоненты (берем self.path,узнаем его contents,сколько файлов стоити прсото к нашему пути добавляем название этого файла или папки)
    
    BOOL isDirectory = NO; //узнаем директория это или нет.(по умолчанию NO)
    
    [[NSFileManager defaultManager] fileExistsAtPath:filePath isDirectory:&isDirectory]; //спрашиваем существует ли файл по такому пути с возвратом BOOL и является он директорией. Если является,то поменяет на "YES"
    
    return isDirectory;
}

- (void) dealloc {
    
    NSLog(@"controller with path %@ has been deallocated",self.path);

}
- (void) viewDidAppear:(BOOL)animated { // когда view появилась на экране

    [super viewDidAppear:animated];
    
    NSLog(@"path = %@",self.path); //путь
    NSLog(@"view controllers on stack = %lu",[self.navigationController.viewControllers count]); //кол-во контроллеров на стеке
    NSLog(@"index on stack %lu",[self.navigationController.viewControllers indexOfObject:self]); //узнаем индек нашего контроллера
}

#pragma mark -Action

- (void) actionBackToRoot:(UIBarButtonItem*) sender {

    [self.navigationController popToRootViewControllerAnimated:YES];
}

@end
