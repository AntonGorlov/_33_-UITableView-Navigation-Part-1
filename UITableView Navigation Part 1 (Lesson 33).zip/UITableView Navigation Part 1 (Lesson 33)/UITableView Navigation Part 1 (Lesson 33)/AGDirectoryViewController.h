//
//  AGDirectoryViewController.h
//  UITableView Navigation Part 1 (Lesson 33)
//
//  Created by Anton Gorlov on 05.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGDirectoryViewController : UITableViewController


- (id) initWithFolderPath:(NSString*) path; //соз конструктор,который передаеь какой-то path

@end
