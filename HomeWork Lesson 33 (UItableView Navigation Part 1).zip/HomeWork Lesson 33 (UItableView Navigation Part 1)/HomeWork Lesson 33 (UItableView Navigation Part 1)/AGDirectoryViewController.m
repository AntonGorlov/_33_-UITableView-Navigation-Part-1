//
//  AGDirectoryViewController.m
//  HomeWork Lesson 33 (UItableView Navigation Part 1)
//
//  Created by Anton Gorlov on 06.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGDirectoryViewController.h"
#import "AGFolder.h"

@interface AGDirectoryViewController ()
@property (strong,nonatomic) NSString* path;
@property (strong,nonatomic) NSArray* contents; // all files and folders at directory


@end

/*
 Я рекомендую вам немного задержаться на этом уроке и снова попрактиковать таблицы. Также будет довольно таки неплохо если вы углубитесь в NSFileManager
 
 Ученик.
 
 1. Добавьте возможность создавать директории
 2. Добавьте возможность удалять файлы и папки 

*/
@implementation AGDirectoryViewController

- (id) initWithFolderPath:(NSString*) path {

    self = [super initWithStyle:UITableViewStyleGrouped];
    
    if (self) {
        self.path = path;
        
        NSError* error = nil;
        
        self.contents = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:self.path
                                                                            error:&error];
        
        
        
        if (error) {
            
            NSLog(@"%@", [error localizedDescription]);
            
        }
    }
    return self;
}


- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    [self statusBarInsets];
    
    self.navigationItem.title = [self.path lastPathComponent];
    
    
    if ([self.navigationController.viewControllers count] > 1) {
        UIBarButtonItem* item = [[UIBarButtonItem alloc] initWithTitle:@"Home"
                                                                 style:UIBarButtonItemStylePlain
                                                                target:self
                                                                action:@selector(actionBackToRoot:)];
        
        self.navigationItem.rightBarButtonItem = item;
    }
    
   
    
    
    
  

   }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - DirectoryAtIndexPath

- (BOOL) isDirectoryAtIndexPath:(NSIndexPath*) indexPath {
    
 
    NSString* fileName = [self.contents objectAtIndex:indexPath.row];
    NSString* filePath = [self.path stringByAppendingPathComponent:fileName];
    
    BOOL isDirectory = NO;
    
    [[NSFileManager defaultManager] fileExistsAtPath:filePath isDirectory:&isDirectory];
    

    return isDirectory;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    
    if ([self isDirectoryAtIndexPath:indexPath]) {
        
        NSString* fileName = [self.contents objectAtIndex:indexPath.row];
        NSString* path = [self.path stringByAppendingPathComponent:fileName];
        
        AGDirectoryViewController* vc = [[AGDirectoryViewController alloc] initWithFolderPath:path];
        [self.navigationController pushViewController:vc animated:YES];
        
    }
    /*
    if (indexPath.row == 0) {
        
        AGFolder* directory = [self.contents objectAtIndex:[self isDirectoryAtIndexPath:indexPath]];
        NSMutableArray* tempArray = nil;
        
        if (directory.folders) {
             tempArray = [NSMutableArray arrayWithArray:directory.folders];
        }else {
            tempArray = [NSMutableArray array];
        }
         NSInteger newIndex = 0;
        
        [tempArray insertObject:self.contents atIndex:newIndex]; // The object  wrong insert
        directory.folders = tempArray;
        
        [self.tableView beginUpdates];
        
        NSIndexPath* newIndexpath = [NSIndexPath indexPathForItem:newIndex +1 inSection:indexPath.section];
        [self.tableView insertRowsAtIndexPaths:@[newIndexpath] withRowAnimation:UITableViewRowAnimationFade];
        
        [self.tableView endUpdates];
     
    }
     */
}


#pragma mark - UITableViewDataSource


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return [self.contents count] ;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    if (indexPath.row == 0 ) {
        
        static NSString* addFolderIdentifier = @"AddFolderIdentifier";
        
        UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:addFolderIdentifier];
        
        
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:addFolderIdentifier];
            cell.textLabel.textColor = [UIColor blueColor];
            cell.textLabel.text = @"Add new folder";
        }
        return cell;
        
    }else {
    
        static NSString* identifier = @"cell";
        
        UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        
        if (!cell) {
            
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
            
            NSString* fileName = [self.contents objectAtIndex:indexPath.row];
            
            cell.textLabel.text = fileName;
            
            if ([self isDirectoryAtIndexPath:indexPath]) {
                
                cell.imageView.image = [UIImage imageNamed:@"folder.png"];
                
            }else {
                
                cell.imageView.image = [UIImage imageNamed:@"file.png"];
                
            }
            
        }
        
        return cell;
    }
 
}

#pragma mark - Actions

- (void) actionBackToRoot:(UIBarButtonItem*) sender {

    [self.navigationController popToRootViewControllerAnimated:YES];

}
#pragma mark - statusBarInsets

- (void) statusBarInsets {

    UIEdgeInsets contentInsets = UIEdgeInsetsMake(-35, 0, 0, 0);
    UIEdgeInsets separatorInsets = UIEdgeInsetsMake(0, 0, 0, 20);
    
    self.tableView.contentInset = contentInsets;
    self.tableView.scrollIndicatorInsets = contentInsets;
    self.tableView.separatorInset = separatorInsets;
  

}

@end
