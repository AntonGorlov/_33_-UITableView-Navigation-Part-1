//
//  AppDelegate.h
//  HomeWork Lesson 33 (UItableView Navigation Part 1)
//
//  Created by Anton Gorlov on 06.04.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

